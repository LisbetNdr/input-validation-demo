const express = require('express');
const app = express();
const { validateRegistration } = require('./middleware/validator');

app.use(express.json());

app.post('/register', validateRegistration, (req, res) => {
    res.status(201).json({
        success: true,
        message: "User registered successfully!",
        data: req.body
    });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));