# Tugas Input Validation Demo - Node.js & Express

Proyek ini dibuat untuk mendemonstrasikan cara melakukan validasi input pada API menggunakan Express Middleware.

## 📝 Langkah Pengerjaan

### 1. Project Setup
- Membuat folder proyek dan inisialisasi npm dengan `npm init -y`.
- Menginstall framework Express menggunakan perintah `npm install express`.

### 2. Express Server Setup
- Membuat file `server.js` sebagai entry point aplikasi.
- Mengaktifkan middleware `express.json()` agar server dapat membaca data dalam format JSON.
- Membuat route POST `/register` untuk menerima input pengguna.

### 3. Input Validation Logic
Membuat middleware di folder `middleware/validator.js` dengan aturan:
- **Required Fields**: Memastikan Nama, Email, dan Password tidak kosong.
- **Email Validation**: Mengecek format email menggunakan Regular Expression (Regex).
- **Password Validation**: Memastikan panjang password minimal 8 karakter.

### 4. Pengiriman Error yang Terstruktur
- Jika input tidak valid, server akan mengirim respon JSON dengan status code `400` atau `422` dan pesan error yang jelas.

## 🚀 Cara Menjalankan Proyek

1. Install dependensi:
   ```bash
   npm install